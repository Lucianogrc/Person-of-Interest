/*using UnityEngine;


public class Cow : MonoBehaviour
{
    [Header("Wandering Area Borders")]
    public Transform northBorder;
    public Transform southBorder;
    public Transform eastBorder;
    public Transform westBorder;

    [Header("Movement Settings")]
    public float moveSpeed = 2f;
    public float rotationSpeed = 3f;
    public float directionChangeInterval = 2f;

    [Header("Collision Field")]
    public SphereCollider collisionField; // Should be a trigger collider

    private Vector3 targetDirection;
    private float directionChangeTimer;
    private bool canMove = true;

    void Start()
    {
        PickNewDirection();
        directionChangeTimer = directionChangeInterval;
    }

    void Update()
    {
        directionChangeTimer -= Time.deltaTime;
        if (directionChangeTimer <= 0f || !canMove)
        {
            Debug.Log($"[Cow] Picking new direction. CanMove: {canMove}");
            PickNewDirection();
            directionChangeTimer = directionChangeInterval;
        }

        // Rotate towards target direction (Y axis only, preserve x=-90 for standing pose)
        if (targetDirection != Vector3.zero)
        {
            Quaternion targetRot = Quaternion.LookRotation(new Vector3(targetDirection.x, 0, targetDirection.z), Vector3.up);
            Vector3 euler = Quaternion.Slerp(Quaternion.Euler(-90, transform.eulerAngles.y, 0),
                                             Quaternion.Euler(-90, targetRot.eulerAngles.y, 0),
                                             rotationSpeed * Time.deltaTime).eulerAngles;
            transform.rotation = Quaternion.Euler(-90, euler.y, 0);
            Debug.Log($"[Cow] Rotating to direction: {targetDirection}");
        }

        // Only move if not blocked
        if (canMove && targetDirection != Vector3.zero)
        {
            Vector3 nextPos = transform.position + targetDirection * moveSpeed * Time.deltaTime;
            if (IsWithinBorders(nextPos))
            {
                Debug.Log($"[Cow] Moving to {nextPos}");
                transform.position = nextPos;
            }
            else
            {
                Debug.Log("[Cow] Border reached, picking new direction");
                PickNewDirection();
            }
        }
    }

    void PickNewDirection()
    {
        // Try up to 10 times to find a valid direction
        for (int i = 0; i < 10; i++)
        {
            float angle = Random.Range(0f, 360f);
            Vector3 dir = new Vector3(Mathf.Cos(angle * Mathf.Deg2Rad), 0, Mathf.Sin(angle * Mathf.Deg2Rad)).normalized;
            Vector3 testPos = transform.position + dir * (collisionField != null ? collisionField.radius * 2f : 1f);
            if (IsWithinBorders(testPos) && !IsDirectionBlocked(dir))
            {
                Debug.Log($"[Cow] New direction chosen: {dir}");
                targetDirection = dir;
                canMove = true;
                return;
            }
        }
        // If no valid direction found, stop moving
        Debug.Log("[Cow] No valid direction found, stopping movement");
        canMove = false;
        targetDirection = Vector3.zero;
    }

    bool IsWithinBorders(Vector3 pos)
    {
        if (northBorder != null && pos.z > northBorder.position.z) { Debug.Log("[Cow] Would cross north border"); return false; }
        if (southBorder != null && pos.z < southBorder.position.z) { Debug.Log("[Cow] Would cross south border"); return false; }
        if (eastBorder != null && pos.x > eastBorder.position.x) { Debug.Log("[Cow] Would cross east border"); return false; }
        if (westBorder != null && pos.x < westBorder.position.x) { Debug.Log("[Cow] Would cross west border"); return false; }
        return true;
    }

    bool IsDirectionBlocked(Vector3 dir)
    {
        if (collisionField == null) return false;
        Vector3 origin = collisionField.transform.position;
        float radius = collisionField.radius * collisionField.transform.lossyScale.x;
        float checkDist = radius * 1.5f;
        RaycastHit[] hits = Physics.SphereCastAll(origin, radius, dir, checkDist);
        foreach (var hit in hits)
        {
            if (hit.collider != collisionField && hit.collider.transform != this.transform && hit.collider.tag != "Ground")
            {
                Debug.Log($"[Cow] Direction blocked by {hit.collider.name}");
                return true;
            }
        }
        return false;
    }

    // Optional: If you want to use OnTriggerStay for more complex avoidance
    void OnTriggerStay(Collider other)
    {
        if (other.tag != "Ground" && other != collisionField)
        {
            canMove = false;
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (other.tag != "Ground" && other != collisionField)
        {
            canMove = true;
        }
    }
}
*/

using UnityEngine;


public class Cow : MonoBehaviour
{
    [Header("Wandering Area Borders")]
    public Transform northBorder;
    public Transform southBorder;
    public Transform eastBorder;
    public Transform westBorder;

    [Header("Movement Settings")]
    public float moveSpeed = 2f;
    public float rotationSpeed = 3f;
    public float directionChangeInterval = 2f;

    [Header("Collision Field")]
    public SphereCollider collisionField; // Should be a trigger collider

    private Vector3 targetDirection;
    private float directionChangeTimer;
    private bool canMove = true;

    void Start()
    {
        PickNewDirection();
        directionChangeTimer = directionChangeInterval;
    }

    void Update()
    {
        directionChangeTimer -= Time.deltaTime;
        if (directionChangeTimer <= 0f || !canMove)
        {
            Debug.Log($"[Cow] Picking new direction. CanMove: {canMove}");
            PickNewDirection();
            directionChangeTimer = directionChangeInterval;
        }

        // Rotate towards target direction (Y axis only, standing pose x=0)
        if (targetDirection != Vector3.zero)
        {
            Quaternion targetRot = Quaternion.LookRotation(new Vector3(targetDirection.x, 0, targetDirection.z), Vector3.up);
            Vector3 euler = Quaternion.Slerp(transform.rotation, targetRot, rotationSpeed * Time.deltaTime).eulerAngles;
            transform.rotation = Quaternion.Euler(0, euler.y, 0);
            Debug.Log($"[Cow] Rotating to direction: {targetDirection}");
        }

        // Only move if not blocked
        if (canMove && targetDirection != Vector3.zero)
        {
            Vector3 nextPos = transform.position + targetDirection * moveSpeed * Time.deltaTime;
            if (IsWithinBorders(nextPos))
            {
                Debug.Log($"[Cow] Moving to {nextPos}");
                transform.position = nextPos;
            }
            else
            {
                Debug.Log("[Cow] Border reached, picking new direction");
                PickNewDirection();
            }
        }
    }

    void PickNewDirection()
    {
        // Try up to 10 times to find a valid direction
        for (int i = 0; i < 10; i++)
        {
            float angle = Random.Range(0f, 360f);
            Vector3 dir = new Vector3(Mathf.Cos(angle * Mathf.Deg2Rad), 0, Mathf.Sin(angle * Mathf.Deg2Rad)).normalized;
            Vector3 testPos = transform.position + dir * (collisionField != null ? collisionField.radius * 2f : 1f);
            if (IsWithinBorders(testPos) && !IsDirectionBlocked(dir))
            {
                Debug.Log($"[Cow] New direction chosen: {dir}");
                targetDirection = dir;
                canMove = true;
                return;
            }
        }
        // If no valid direction found, stop moving
        Debug.Log("[Cow] No valid direction found, stopping movement");
        canMove = false;
        targetDirection = Vector3.zero;
    }

    bool IsWithinBorders(Vector3 pos)
    {
        if (northBorder != null && pos.z > northBorder.position.z) { Debug.Log("[Cow] Would cross north border"); return false; }
        if (southBorder != null && pos.z < southBorder.position.z) { Debug.Log("[Cow] Would cross south border"); return false; }
        if (eastBorder != null && pos.x > eastBorder.position.x) { Debug.Log("[Cow] Would cross east border"); return false; }
        if (westBorder != null && pos.x < westBorder.position.x) { Debug.Log("[Cow] Would cross west border"); return false; }
        return true;
    }

    bool IsDirectionBlocked(Vector3 dir)
    {
        if (collisionField == null) return false;
        Vector3 origin = collisionField.transform.position;
        float radius = collisionField.radius * collisionField.transform.lossyScale.x;
        float checkDist = radius * 1.5f;
        RaycastHit[] hits = Physics.SphereCastAll(origin, radius, dir, checkDist);
        foreach (var hit in hits)
        {
            if (hit.collider != collisionField && hit.collider.transform != this.transform && hit.collider.tag != "Ground")
            {
                Debug.Log($"[Cow] Direction blocked by {hit.collider.name}");
                return true;
            }
        }
        return false;
    }

    // Optional: If you want to use OnTriggerStay for more complex avoidance
    void OnTriggerStay(Collider other)
    {
        if (other.tag != "Ground" && other != collisionField)
        {
            canMove = false;
        }
    }

    void OnTriggerExit(Collider other)
    {
        if (other.tag != "Ground" && other != collisionField)
        {
            canMove = true;
        }
    }
}
