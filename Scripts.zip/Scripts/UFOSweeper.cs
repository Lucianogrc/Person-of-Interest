using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Serpentine "lawn-mower" sweep over the play area.
/// - Auto-reads bounds from Terrain.activeTerrain (or manual box).
/// - Keeps constant hoverHeight above ground (raycast to Ground layer).
/// - Smooth turns, loops when done.
/// </summary>
[RequireComponent(typeof(Rigidbody), typeof(Collider))]
public class UFOSweeper : MonoBehaviour
{
    [Header("Area")]
    [Tooltip("If true, use Terrain.activeTerrain bounds. If false, use Manual Bounds below.")]
    public bool useTerrainBounds = true;

    [Tooltip("Margin kept from edges (meters).")]
    public float edgeMargin = 5f;

    [Tooltip("Distance between parallel sweep lanes (meters).")]
    public float laneSpacing = 20f;

    [Tooltip("Manual area center (XZ). Ignored if useTerrainBounds = true.")]
    public Vector3 manualCenter = Vector3.zero;

    [Tooltip("Manual area size (X,Z). Ignored if useTerrainBounds = true.")]
    public Vector2 manualSize = new Vector2(200f, 200f);

    [Header("Flight")]
    [Tooltip("Meters per second.")]
    public float moveSpeed = 7.5f;

    [Tooltip("How quickly to rotate toward the next waypoint.")]
    public float turnLerp = 4f;

    [Tooltip("Desired height above ground (meters).")]
    public float hoverHeight = 6f;

    [Tooltip("How quickly Y follows target hover height.")]
    public float hoverLerp = 6f;

    [Tooltip("Layer(s) considered ground for hover raycasts.")]
    public LayerMask groundMask;

    [Tooltip("How close to a waypoint before advancing (meters).")]
    public float waypointTolerance = 1.0f;

    [Tooltip("If true, start from the lane endpoint closest to current position.")]
    public bool startAtNearest = true;

    [Header("Gizmos")]
    public bool drawArea = true;
    public bool drawPath = true;
    public Color areaColor = new Color(0f, 0.8f, 1f, 0.25f);
    public Color pathColor = new Color(0.2f, 1f, 0.2f, 0.9f);

    // Internal
    private List<Vector3> _path = new List<Vector3>();  // world-space, Y ignored (XZ path)
    private int _idx;
    private float _minX, _maxX, _minZ, _maxZ;
    private bool _haveArea;

    void Start()
    {
        BuildArea();
        BuildPath();
        SnapStartIndex();
        // Kinematic rigidbody recommended; we still set transform directly.
        var rb = GetComponent<Rigidbody>();
        if (rb) { rb.isKinematic = true; rb.useGravity = false; }
    }

    void Update()
    {
        if (_path.Count == 0) return;

        // ----- Horizontal steering toward next waypoint (XZ only)
        Vector3 p = transform.position;
        Vector3 targetFlat = new Vector3(_path[_idx].x, p.y, _path[_idx].z);

        Vector3 to = (targetFlat - p);
        to.y = 0f;

        if (to.magnitude <= waypointTolerance)
        {
            _idx = (_idx + 1) % _path.Count;
            return;
        }

        Vector3 dir = to.normalized;
        if (dir.sqrMagnitude > 0.0001f)
        {
            Quaternion face = Quaternion.LookRotation(dir, Vector3.up);
            transform.rotation = Quaternion.Slerp(transform.rotation, face, Time.deltaTime * turnLerp);
        }
        transform.position += transform.forward * (moveSpeed * Time.deltaTime);

        // ----- Hover: keep Y at ground + hoverHeight
        MaintainHover();
    }

    private void MaintainHover()
    {
        Vector3 origin = transform.position + Vector3.up * 200f; // cast from above
        if (Physics.Raycast(origin, Vector3.down, out RaycastHit hit, 1000f, groundMask, QueryTriggerInteraction.Ignore))
        {
            float targetY = hit.point.y + hoverHeight;
            Vector3 pos = transform.position;
            pos.y = Mathf.Lerp(pos.y, targetY, Time.deltaTime * hoverLerp);
            transform.position = pos;
        }
        // else: keep current Y if ground not hit this frame
    }

    private void BuildArea()
    {
        _haveArea = false;

        if (useTerrainBounds && Terrain.activeTerrain != null && Terrain.activeTerrain.terrainData != null)
        {
            var t = Terrain.activeTerrain;
            Vector3 tpos = t.GetPosition();
            Vector3 ts = t.terrainData.size;
            _minX = tpos.x + edgeMargin;
            _maxX = tpos.x + ts.x - edgeMargin;
            _minZ = tpos.z + edgeMargin;
            _maxZ = tpos.z + ts.z - edgeMargin;
            _haveArea = true;
        }
        else
        {
            // Manual rectangle in world space
            float halfX = Mathf.Max(1f, manualSize.x * 0.5f);
            float halfZ = Mathf.Max(1f, manualSize.y * 0.5f);
            _minX = manualCenter.x - halfX + edgeMargin;
            _maxX = manualCenter.x + halfX - edgeMargin;
            _minZ = manualCenter.z - halfZ + edgeMargin;
            _maxZ = manualCenter.z + halfZ - edgeMargin;
            _haveArea = true;
        }

        // Safety clamp
        if (_maxX <= _minX) _maxX = _minX + 1f;
        if (_maxZ <= _minZ) _maxZ = _minZ + 1f;
        laneSpacing = Mathf.Max(1f, laneSpacing);
    }

    private void BuildPath()
    {
        _path.Clear();
        if (!_haveArea) return;

        // Generate serpentine lanes along Z (rows), sweeping X back and forth
        float z = _minZ;
        bool toRight = true;
        float maxZ = _maxZ;

        while (z <= maxZ + 0.001f)
        {
            float xA = _minX;
            float xB = _maxX;
            if (!toRight) { var tmp = xA; xA = xB; xB = tmp; }

            _path.Add(new Vector3(xA, 0f, z));
            _path.Add(new Vector3(xB, 0f, z));

            z += laneSpacing;
            toRight = !toRight;
        }

        // Ensure last row exactly on maxZ if spacing didn't land on it
        if (_path.Count >= 2)
        {
            Vector3 last = _path[_path.Count - 1];
            if (Mathf.Abs(last.z - _maxZ) > 0.5f)
            {
                // Add a final pass on maxZ in the opposite direction
                float xA = toRight ? _minX : _maxX;
                float xB = toRight ? _maxX : _minX;
                _path.Add(new Vector3(xA, 0f, _maxZ));
                _path.Add(new Vector3(xB, 0f, _maxZ));
            }
        }
    }

    private void SnapStartIndex()
    {
        if (!startAtNearest || _path.Count == 0) { _idx = 0; return; }

        // choose nearest waypoint in XZ to our current position
        Vector2 p = new Vector2(transform.position.x, transform.position.z);
        float bestD = float.MaxValue;
        int bestI = 0;
        for (int i = 0; i < _path.Count; i++)
        {
            Vector2 w = new Vector2(_path[i].x, _path[i].z);
            float d = (w - p).sqrMagnitude;
            if (d < bestD) { bestD = d; bestI = i; }
        }
        _idx = bestI;
    }

#if UNITY_EDITOR
    void OnDrawGizmosSelected()
    {
        if (!drawArea && !drawPath) return;

        // Area
        if (drawArea)
        {
            // preview area even in editor: use current settings
            float minX = _minX, maxX = _maxX, minZ = _minZ, maxZ = _maxZ;
            if (Application.isPlaying == false)
            {
                // compute a preview
                if (useTerrainBounds && Terrain.activeTerrain && Terrain.activeTerrain.terrainData)
                {
                    var t = Terrain.activeTerrain; var td = t.terrainData;
                    Vector3 tpos = t.GetPosition(); Vector3 ts = td.size;
                    minX = tpos.x + edgeMargin; maxX = tpos.x + ts.x - edgeMargin;
                    minZ = tpos.z + edgeMargin; maxZ = tpos.z + ts.z - edgeMargin;
                }
                else
                {
                    float hx = Mathf.Max(1f, manualSize.x * 0.5f);
                    float hz = Mathf.Max(1f, manualSize.y * 0.5f);
                    minX = manualCenter.x - hx + edgeMargin;
                    maxX = manualCenter.x + hx - edgeMargin;
                    minZ = manualCenter.z - hz + edgeMargin;
                    maxZ = manualCenter.z + hz - edgeMargin;
                }
            }

            Gizmos.color = areaColor;
            Vector3 a = new Vector3(minX, transform.position.y, minZ);
            Vector3 b = new Vector3(maxX, transform.position.y, minZ);
            Vector3 c = new Vector3(maxX, transform.position.y, maxZ);
            Vector3 d = new Vector3(minX, transform.position.y, maxZ);
            Gizmos.DrawLine(a, b); Gizmos.DrawLine(b, c); Gizmos.DrawLine(c, d); Gizmos.DrawLine(d, a);
        }

        // Path
        if (drawPath && _path != null && _path.Count > 1)
        {
            Gizmos.color = pathColor;
            for (int i = 0; i < _path.Count - 1; i++)
            {
                Vector3 p0 = new Vector3(_path[i].x, transform.position.y, _path[i].z);
                Vector3 p1 = new Vector3(_path[i + 1].x, transform.position.y, _path[i + 1].z);
                Gizmos.DrawLine(p0, p1);
            }
        }
    }
#endif
}
